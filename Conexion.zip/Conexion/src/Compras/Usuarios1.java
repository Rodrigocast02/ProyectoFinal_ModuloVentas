
package Compras;
import static Compras.Usuarios.res;
import java.sql.*;
import conexion.conexion;
import java.sql.Connection;
import javax.swing.JOptionPane;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import conexion.procedi;
import java.sql.PreparedStatement;


public class Usuarios1 extends javax.swing.JFrame {

    PreparedStatement ps;
    static ResultSet res;
    
    
    public Usuarios1() {
        initComponents();
       this.setLocationRelativeTo(null);
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        btnbuscar = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txtnom = new javax.swing.JTextField();
        txtapellidos = new javax.swing.JTextField();
        txtpuesto = new javax.swing.JTextField();
        txtorden = new javax.swing.JTextField();
        rbmasculino = new javax.swing.JRadioButton();
        rbfemenino = new javax.swing.JRadioButton();
        btnregistar = new javax.swing.JButton();
        btnmostrar = new javax.swing.JButton();
        btnmodificar = new javax.swing.JButton();
        btneliminar = new javax.swing.JButton();
        btnlimpiar = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        txtusuario = new javax.swing.JTextField();
        txtcontra = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        txtbus = new javax.swing.JTextField();
        txtfondo = new javax.swing.JLabel();
        txtid = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        btnregrasar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Id", "Nombre", "Apellidos", "Puesto", "Ordenes", "Sexo", "usuario", "contraseña"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class, java.lang.String.class, java.lang.Object.class, java.lang.Object.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 140, 520, 100));

        btnbuscar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagen/bus.png"))); // NOI18N
        btnbuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnbuscarActionPerformed(evt);
            }
        });
        getContentPane().add(btnbuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 40, 80, -1));

        jLabel2.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 14)); // NOI18N
        jLabel2.setText("Nombres");

        jLabel3.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 14)); // NOI18N
        jLabel3.setText("Apellidos");

        jLabel4.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 14)); // NOI18N
        jLabel4.setText("Puesto");

        jLabel5.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 14)); // NOI18N
        jLabel5.setText("No. Ordenes de Compras");

        jLabel6.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 14)); // NOI18N
        jLabel6.setText("Sexo");

        rbmasculino.setText("Masculino");

        rbfemenino.setText("Femnino");

        btnregistar.setText("Registrar");
        btnregistar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnregistarActionPerformed(evt);
            }
        });

        btnmostrar.setText("Mostrar");
        btnmostrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnmostrarActionPerformed(evt);
            }
        });

        btnmodificar.setText("Modificar");
        btnmodificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnmodificarActionPerformed(evt);
            }
        });

        btneliminar.setText("Eliminar");
        btneliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btneliminarActionPerformed(evt);
            }
        });

        btnlimpiar.setText("Limpiar");
        btnlimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnlimpiarActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 18)); // NOI18N
        jLabel7.setText("Usuarios");

        jLabel8.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 14)); // NOI18N
        jLabel8.setText("Usuario");

        jLabel9.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 14)); // NOI18N
        jLabel9.setText("Contraseña");

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagen/usu.png"))); // NOI18N

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(rbfemenino)
                .addGap(160, 160, 160))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel9)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addGap(49, 49, 49)
                                .addComponent(rbmasculino))
                            .addComponent(jLabel8)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(btnregistar)
                                .addGap(28, 28, 28)
                                .addComponent(btnmostrar)
                                .addGap(18, 18, 18)
                                .addComponent(btnmodificar)
                                .addGap(18, 18, 18)
                                .addComponent(btneliminar))
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                    .addGap(8, 8, 8)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel3)
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addComponent(jLabel4)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(txtapellidos, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                .addComponent(txtpuesto, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addComponent(jLabel2)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(txtnom, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(txtusuario, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                            .addComponent(txtorden, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addComponent(txtcontra, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGap(8, 8, 8)))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(146, 146, 146)
                        .addComponent(btnlimpiar)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jButton1))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(39, 39, 39)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(txtnom, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(26, 26, 26)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(txtapellidos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(24, 24, 24)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(txtpuesto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(29, 29, 29)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txtorden, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(37, 37, 37)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(txtusuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(39, 39, 39)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtcontra, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(rbmasculino)
                    .addComponent(rbfemenino))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnregistar)
                    .addComponent(btnmostrar)
                    .addComponent(btnmodificar)
                    .addComponent(btneliminar))
                .addGap(18, 18, 18)
                .addComponent(btnlimpiar)
                .addContainerGap(17, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 420, 520));

        txtbus.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 14)); // NOI18N
        getContentPane().add(txtbus, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 62, 120, 30));

        txtfondo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagen/fondo.png"))); // NOI18N
        txtfondo.setText("jLabel7");
        getContentPane().add(txtfondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 10, 560, 610));
        getContentPane().add(txtid, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 40, 144, -1));

        jLabel1.setText("ID");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 40, -1, -1));

        btnregrasar.setText("Regrasar");
        btnregrasar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnregrasarActionPerformed(evt);
            }
        });
        getContentPane().add(btnregrasar, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 560, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnregistarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnregistarActionPerformed
        String nombre = txtnom.getText();
        String apellidos = txtapellidos.getText();
        String puesto = txtpuesto.getText();
        int orden = Integer.parseInt(txtorden.getText());
        String usuario = txtusuario.getText();
        String contra = txtcontra.getText();
        String sexo;
                if (rbmasculino.isSelected()==true){
                    sexo="M";
                }else if (rbfemenino.isSelected()==true){
                    sexo="F";
                }else{
                    sexo="M";
                }
                try{
                    Connection con = conexion.getConexion();
                    PreparedStatement ps = con.prepareStatement("INSERT INTO Usuarios (Nombre,Apellidos, Puesto, No_Orden_compras, sexo, usuario, contra) VALUES (?,?,?,?,?,?,?)");
                    ps.setString(1, nombre);
                    ps.setString(2, apellidos);
                    ps.setString(3, puesto);
                    ps.setInt(4, orden);
                     ps.setString(5, sexo);
                    ps.setString(6, usuario);
                    ps.setString(7, contra);
                    
                  
                    ps.executeUpdate();
                    JOptionPane.showMessageDialog(null, "Registro Guardado");
                    limpiar ();
                   
                }catch(SQLException e){
                    JOptionPane.showMessageDialog(null, e.toString());
                    
                } 
                    
    }//GEN-LAST:event_btnregistarActionPerformed

    private void btnmostrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnmostrarActionPerformed
         cargar();
    }//GEN-LAST:event_btnmostrarActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
      
        try{
           int fila = jTable1.getSelectedRow();
           int id = Integer.parseInt(jTable1.getValueAt(fila, 0).toString());
          
        PreparedStatement ps;
        ResultSet rs;
            Connection con = conexion.getConexion();
            ps= con.prepareStatement("SELECT Nombre, Apellidos, Puesto, No_Orden_compras, sexo, usuario, contra FROM Usuarios WHERE ID=?");
            ps.setInt(1, id);
           rs = ps.executeQuery();
           
           while(rs.next()){
               txtid.setText(String.valueOf(id));
               txtnom.setText(rs.getString("Nombre"));
               txtapellidos.setText(rs.getString("Apellidos"));
               txtpuesto.setText(rs.getString("Puesto"));
               txtusuario.setText(rs.getString("usuario"));
                txtcontra.setText(rs.getString("contra"));
               txtorden.setText(rs.getString("No_Orden_compras"));
               if (rs.getString("sexo").equals("M")){
                   rbmasculino.setSelected(true);
               }else if (rs.getString("sexo").equals("F")){
                   rbfemenino.setSelected(true);
               }
                
           }
        }catch(SQLException e){
           JOptionPane.showMessageDialog(null, e.toString());  
        }
    }//GEN-LAST:event_jTable1MouseClicked

    private void btnmodificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnmodificarActionPerformed
       
        int id = Integer.parseInt(txtid.getText());
        String nombre = txtnom.getText();
        String apellidos = txtapellidos.getText();
        String puesto = txtpuesto.getText();
        int orden = Integer.parseInt(txtorden.getText());
        String usuario = txtusuario.getText();
        String contra = txtcontra.getText();
        String sexo;
                if (rbmasculino.isSelected()==true){
                    sexo="M";
                }else if (rbfemenino.isSelected()==true){
                    sexo="F";
                }else{
                    sexo="M";
                }
                try{
                    Connection con = conexion.getConexion();
                    PreparedStatement ps = con.prepareStatement("UPDATE Usuarios SET Nombre=?,Apellidos=?, Puesto=?, No_Orden_compras=?, sexo=?, usuario=?, contra=? WHERE ID=?");
                    ps.setString(1, nombre);
                    ps.setString(2, apellidos);
                    ps.setString(3, puesto);
                    ps.setInt(4, orden);
                    ps.setString(5, sexo);
                    ps.setString(6, usuario);
                    ps.setString(7, contra);
                    ps.setInt(8, id);
                    ps.executeUpdate();
                    JOptionPane.showMessageDialog(null, "Registro Modificado");
                    limpiar ();
                   
                }catch(SQLException e){
                    JOptionPane.showMessageDialog(null, e.toString());
                    
                } 
    }//GEN-LAST:event_btnmodificarActionPerformed

    private void btneliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btneliminarActionPerformed
        int id = Integer.parseInt(txtid.getText());
        
                try{
                    Connection con = conexion.getConexion();
                    PreparedStatement ps = con.prepareStatement("DELETE FROM Usuarios WHERE ID=?");
                    
                   
                    ps.setInt(1, id);
                    ps.executeUpdate();
                    JOptionPane.showMessageDialog(null, "Registro Se Elimino");
                    limpiar ();
                   
                }catch(SQLException e){
                    JOptionPane.showMessageDialog(null, e.toString());
                    
                } 
    }//GEN-LAST:event_btneliminarActionPerformed

    private void btnlimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnlimpiarActionPerformed
        limpiar ();
    }//GEN-LAST:event_btnlimpiarActionPerformed

    private void btnregrasarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnregrasarActionPerformed
       Menu gg = new Menu ();
       gg.setVisible(true);
       dispose();
       
    }//GEN-LAST:event_btnregrasarActionPerformed

    private void btnbuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnbuscarActionPerformed
       Buscar();
    }//GEN-LAST:event_btnbuscarActionPerformed
private void limpiar (){
    jTable1.updateUI();
    txtid.setText("");
    txtnom.setText("");
    txtapellidos.setText("");
    txtpuesto.setText("");
    txtorden.setText("");
    txtusuario.setText("");
    txtcontra.setText("");
    
}
public void cargar(){
        DefaultTableModel modelo = (DefaultTableModel) jTable1.getModel();
        modelo.setRowCount(0);
       
        PreparedStatement ps;
        ResultSet rs;
        ResultSetMetaData rsmd;
        int columnas;
        
        try{
            
            Connection con = conexion.getConexion();
            ps= con.prepareStatement("SELECT id, Nombre, Apellidos, Puesto, No_Orden_compras, sexo, usuario, contra FROM Usuarios");
            
           rs = ps.executeQuery();
           rsmd = rs.getMetaData();
           columnas = rsmd.getColumnCount();
           
           while (rs.next()){
               Object[] fila= new Object[columnas];
               for(int i=0; i<columnas; i++){
                   fila[i]= rs.getObject(i +1);                  
               } 
               modelo.addRow(fila);
           }
            
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, e.toString());
        }
    }
public void Buscar(){
        String codigo = txtbus.getText();
        DefaultTableModel modelo = (DefaultTableModel) jTable1.getModel();
        modelo.setRowCount(0);

        PreparedStatement ps;
        ResultSet rs;
        ResultSetMetaData rsmd;
        int columnas;

        try{

            Connection con = conexion.getConexion();
            ps= con.prepareStatement("SELECT *FROM  Usuarios WHERE Nombre = '"+codigo+"'");

           rs = ps.executeQuery();
           rsmd = rs.getMetaData();
           columnas = rsmd.getColumnCount();

           while (rs.next()){
               Object[] fila= new Object[columnas];
               for(int i=0; i<columnas; i++){
                   fila[i]= rs.getObject(i +1);
               } 
               modelo.addRow(fila);
           }

        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, e.toString());
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Usuarios1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Usuarios1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Usuarios1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Usuarios1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Usuarios1().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnbuscar;
    private javax.swing.JButton btneliminar;
    private javax.swing.JButton btnlimpiar;
    private javax.swing.JButton btnmodificar;
    private javax.swing.JButton btnmostrar;
    private javax.swing.JButton btnregistar;
    private javax.swing.JButton btnregrasar;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JRadioButton rbfemenino;
    private javax.swing.JRadioButton rbmasculino;
    private javax.swing.JTextField txtapellidos;
    private javax.swing.JTextField txtbus;
    private javax.swing.JTextField txtcontra;
    private javax.swing.JLabel txtfondo;
    private javax.swing.JTextField txtid;
    private javax.swing.JTextField txtnom;
    private javax.swing.JTextField txtorden;
    private javax.swing.JTextField txtpuesto;
    private javax.swing.JTextField txtusuario;
    // End of variables declaration//GEN-END:variables

    private void setlocationRelativeTo(Object object) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
