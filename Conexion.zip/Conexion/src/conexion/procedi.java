/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conexion;

import java.sql.CallableStatement;
import java.sql.SQLException;
public class procedi {
     public static void Usuarios(String a, String b, String c,String d,String e)throws SQLException{
        CallableStatement entrada = conexion.getConexion().prepareCall("{call Usuarios(?,?,?,?,?)}");
        entrada.setString(1, a);
        entrada.setString(2, b);
        entrada.setString(3, c);
        entrada.setString(4, d);
        entrada.setString(5, e);
        entrada.execute();
    }
    
    public static void EliminarArticulo(int a)throws SQLException{
        CallableStatement entrada = conexion.getConexion().prepareCall("{call EliminarArticulo(?)}");
        entrada.setInt(1, a);
        entrada.execute();
    }
    
    public static void BuscarArticulo(int a)throws SQLException{
        CallableStatement entrada = conexion.getConexion().prepareCall("{call BuscarArticulo(?)}");
        entrada.setInt(1, a);
        entrada.execute();
    }
    
}
